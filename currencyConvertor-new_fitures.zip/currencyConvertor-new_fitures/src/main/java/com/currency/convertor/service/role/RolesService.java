package com.currency.convertor.service.role;

public interface RolesService {

    void saveToDb();
}
